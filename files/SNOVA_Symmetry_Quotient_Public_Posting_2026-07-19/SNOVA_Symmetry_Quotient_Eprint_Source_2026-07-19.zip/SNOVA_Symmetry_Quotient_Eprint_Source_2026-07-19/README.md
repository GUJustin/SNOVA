# LaTeX source

Master paper: `paper.tex`  
Anonymous wrapper: `paper_anonymous.tex`  
Confidential disclosure wrapper: `paper_disclosure.tex`

Build with:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_anonymous.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_disclosure.tex
```

The public manuscript is 20 pages. The only build warning in the audited environment is a harmless `amsmath` warning about redefining the `\vec` accent under the class/package combination. There are no undefined references or citations, and no overfull or underfull boxes.
